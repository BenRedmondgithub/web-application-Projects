namespace MyNamespace
{
    public book 
    {
        public int id { get; set; }
        
        public string Title { get; set; }
        
        public string Author { get; set; }
        
    }
}
